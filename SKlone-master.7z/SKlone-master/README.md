SKlone
======

SKlone is a clone of Star Kingdoms, a browser-based strategy game

Uses ASP.NET (web forms, VB.NET) and MS SQL Server

Author: Jonathan Amend

Years in development: 2003-2004

Status: completed but inactive

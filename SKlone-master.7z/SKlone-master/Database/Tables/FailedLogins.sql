﻿CREATE TABLE [dbo].[FailedLogins] (
    [FailedIP] NVARCHAR (16) NOT NULL
);


﻿CREATE TABLE [dbo].[UnitPowerCost] (
    [UnitType]  TINYINT NOT NULL,
    [PowerCost] REAL    NOT NULL
);


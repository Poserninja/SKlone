﻿CREATE TABLE [dbo].[AdminLogins] (
    [LoginIP]   NVARCHAR (16) NOT NULL,
    [LoginDate] DATETIME      NULL,
    [LoginUser] NVARCHAR (50) NULL
);


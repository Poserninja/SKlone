﻿CREATE TABLE [dbo].[LogIns] (
    [LogInIP]   NVARCHAR (16) NOT NULL,
    [LogInDate] DATETIME      NOT NULL,
    [kdID]      INT           NOT NULL
);


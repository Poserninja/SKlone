﻿CREATE TABLE [dbo].[Bans] (
    [BanEmail]     NVARCHAR (256) NULL,
    [BanIP]        NVARCHAR (16)  NULL,
    [BanKDName]    NVARCHAR (24)  NULL,
    [BanRulerName] NVARCHAR (24)  NULL,
    [BanAccount]   NVARCHAR (16)  NULL
);


﻿CREATE TABLE [dbo].[Ticker] (
    [TickTime] REAL NOT NULL
);


﻿/*Calculate Power Produced */

CREATE FUNCTION [dbo].[PowerCheck]
(
	@kid int
)
RETURNS bigint
BEGIN
	DECLARE @MaxPower bigint
    DECLARE @PowerCheck bigint
    DECLARE @Nuclear bigint
    DECLARE @Fusion bigint
    SET @PowerCheck = (SELECT Kingdoms.[Power] FROM Kingdoms WHERE kdID = @kdID)
    SET @Nuclear = (SELECT Built FROM Buildings WHERE BuildingType = 3 AND kdID = @kdID)
    SET @Fusion = (SELECT Built FROM Buildings WHERE BuildingType = 4 AND kdID = @kdID)
    SET @MaxPower = @Nuclear * 500 + @Fusion * 1000
    IF @PowerCheck > @MaxPower SET @PowerCheck = @MaxPower
    IF @PowerCheck < 0 SET @PowerCheck = 0
    RETURN(@PowerCheck)
END
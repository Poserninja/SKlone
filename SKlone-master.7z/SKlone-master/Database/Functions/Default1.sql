﻿CREATE DEFAULT [dbo].[Default1]
	AS 'Unknown'

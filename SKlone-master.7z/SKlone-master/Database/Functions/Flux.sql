﻿/*Created 3/14/2019 by Loki This function lets you get a fluctuation in percentage + or - the given value*/
CREATE VIEW random
AS
SELECT RAND() as  random
Go

Create Function dbo.Flux
(
	@kdID int,
	@Flux int
)
Returns real
Begin
	Declare @FluxRange real
	Set @FluxRange = -1 * @Flux
	Set @FluxRange = (Select Rand() * (@Flux-@FluxRange)) + @FluxRange
Return (@FluxRange)
End


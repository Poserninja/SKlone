﻿/****** Object:  User Defined Function dbo.NewPower    Script Date: 5/1/2004 6:12:46 PM ******/
CREATE FUNCTION dbo.NewPower
	(
		@kdID int
	)
RETURNS bigint
BEGIN
    DECLARE @NewPower bigint
	DECLARE @Nuclear bigint
	DECLARE @Fusion bigint
	DECLARE @Flux bigint
	SET @Nuclear = (SELECT Built FROM Buildings WHERE BuildingType = 3 AND kdID = @kdID)
	SET @Fusion = (SELECT Built FROM Buildings WHERE BuildingType = 4 AND kdID = @kdID)
	/* Flux gives power fluctuation +-@Flux% */
	SET @Flux = 5
	SET @NewPower = (SELECT PlanetTypes.PowerProducedFactor FROM Kingdoms, PlanetTypes WHERE PlanetTypes.PlanetType = Kingdoms.PlanetType AND Kingdoms.kdID = @kdID) * (@Nuclear * 100 + @Fusion * 140) * (1+((SELECT ResearchPercent FROM Research WHERE ResearchType = 1 AND kdID = @kdID) / 100)) * dbo.Flux(@kdID,5) - dbo.PowerNeeded(@kdID)
	RETURN(@NewPower)
END
